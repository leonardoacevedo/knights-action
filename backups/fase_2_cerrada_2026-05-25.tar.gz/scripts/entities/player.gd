extends CharacterBody2D
class_name Player

## Player entity. Orquesta componentes según arquitectura.md.
## Fase 1: movimiento, salto, dash, ataque básico, Furia con decay, Momentum.
## Próximo (Fase 1 backlog): Bloqueo con cargas, feedback de impacto extra.

const SPEED := 400.0
const JUMP_VELOCITY := -850.0     # igual al enemy: paridad base requerida por Leo
const GRAVITY_MULTIPLIER := 2.5

const ATTACK_DURATION := 0.3
const ATTACK_ACTIVE_START := 0.08
const ATTACK_ACTIVE_END := 0.18

## Proyectiles que el player dispara con armas ranged (Arco / Vara).
## Reuse de las mismas escenas que usan Archer / Mage, con team=1.
const PLAYER_ARROW_SCENE: PackedScene = preload("res://scenes/projectiles/projectile_arrow.tscn")
const PLAYER_FIREBALL_SCENE: PackedScene = preload("res://scenes/projectiles/projectile_fireball.tscn")

@export var team: int = 1

# Referencias a hijos (resueltas en _ready).
@onready var sprite: StickFigure = $StickFigure
@onready var health: HealthComponent = $HealthComponent
@onready var furia: FuriaComponent = $FuriaComponent
@onready var dash: DashComponent = $DashComponent
@onready var hitbox: HitboxComponent = $Hitbox
@onready var hurtbox: HurtboxComponent = $Hurtbox
@onready var shield: ShieldComponent = $ShieldComponent
@onready var momentum_particles: GPUParticles2D = $MomentumParticles
@onready var player_stats: PlayerStatsComponent = $PlayerStatsComponent

var is_attacking: bool = false
var current_facing: int = 1

var _gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var _attack_time: float = 0.0
## Si es true, el ATTACK actual es ranged (arco/vara). No activa hitbox melee;
## el proyectil ya fue spawneado al inicio. Solo dura para la animación visual.
var _is_ranged_attack: bool = false
## Si es true, ya disparamos el proyectil en este attack (evita doble spawn).
var _projectile_fired_this_attack: bool = false
## Timestamp del último screen-shake disparado por recibir daño (ms).
## Rate-limit: con multi-enemy las vibraciones encadenadas marean.
const DAMAGE_SHAKE_COOLDOWN_MS: int = 1000
var _last_damage_shake_ms: int = -DAMAGE_SHAKE_COOLDOWN_MS


func _ready() -> void:
	# Wireo cruzado entre componentes (inyección, no get_parent).
	hurtbox.health_component = health
	hurtbox.team = team
	hurtbox.shield = shield
	hitbox.team = team
	dash.hurtbox = hurtbox

	# Inyectar referencias en PlayerStatsComponent antes de recalcular.
	player_stats.health = health
	player_stats.hitbox = hitbox
	player_stats.hurtbox = hurtbox
	# Estado inicial: aplicar stats del equipo actual (si ya hay algo equipado).
	player_stats.recalculate()
	# Suscribirse a cambios de equipo para refrescar el visual de armas en el StickFigure.
	InventorySystem.equipped_changed.connect(_on_equipped_changed)
	_refresh_weapon_visuals()

	# Señales.
	hitbox.hit_landed.connect(_on_hit_landed)
	hurtbox.hit_received.connect(_on_hit_received)
	hurtbox.hit_blocked.connect(_on_hit_blocked)
	health.died.connect(_on_died)

	# Bloqueo: feedback visual del aura sostenida (se activa con block_started).
	shield.block_started.connect(_on_block_started)
	shield.block_ended.connect(_on_block_ended)

	# Recarga de cargas al completar etapa (PvE). GDD §4.3.
	StageManager.stage_cleared.connect(_on_stage_cleared)

	# Feedback visual de Momentum a partir de 5x.
	MomentumSystem.threshold_5x_reached.connect(_on_momentum_threshold_reached)
	MomentumSystem.threshold_5x_lost.connect(_on_momentum_threshold_lost)
	MomentumSystem.momentum_reset.connect(_on_momentum_threshold_lost)

	# Demo: agregar items al inventario SIN equipar.
	# Player arranca sin equipo para playtest balance base; equipa desde la UI in-game.
	call_deferred("_add_default_items_to_inventory")


func _add_default_items_to_inventory() -> void:
	# Items demo de Fase 1 disponibles en la mochila desde el inicio.
	# Set completo para testeo: 1 R1 por slot + R2 surtidos + R3 + R4 boss-tier.
	# Path: resources/items/<slot>/<id>.tres.
	var paths: Array[String] = [
		# R1 (común) — set de partida
		"res://resources/items/weapons/espada_madera.tres",
		"res://resources/items/armor/tunica_aprendiz.tres",
		"res://resources/items/shields/escudo_tablones.tres",
		# R2 (raro)
		"res://resources/items/weapons/espada_hierro.tres",
		"res://resources/items/weapons/arco_corto.tres",
		"res://resources/items/armor/cota_cuero.tres",
		"res://resources/items/shields/escudo_hierro.tres",
		# R3 (épico)
		"res://resources/items/weapons/espada_runica.tres",
		"res://resources/items/weapons/vara_cristal.tres",
		"res://resources/items/armor/coraza_placas.tres",
		"res://resources/items/shields/escudo_torre.tres",
		# R4 (legendario / boss drop)
		"res://resources/items/weapons/martillo_guardian.tres",
	]
	for path: String in paths:
		var item: ItemData = load(path) as ItemData
		if item == null:
			push_warning("Player: no se pudo cargar item demo en '%s'" % path)
			continue
		InventorySystem.add_item(item)


func _physics_process(delta: float) -> void:
	# Dash tiene prioridad sobre todo.
	if dash.is_dashing:
		velocity.x = dash.get_dash_velocity_x()
		velocity.y = 0.0
		move_and_slide()
		return

	_apply_gravity(delta)
	_handle_input()
	_tick_attack(delta)
	move_and_slide()


func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y += _gravity * GRAVITY_MULTIPLIER * delta


func _handle_input() -> void:
	# is_action_pressed (no just_pressed) → joystick "arriba" mantiene salto al
	# tocar el suelo. Funciona idéntico para teclado: si mantenés Space, también
	# saltás de nuevo apenas aterrizás. Comportamiento de plataformero mobile.
	if Input.is_action_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Bloqueo: hold mientras no estés en attack/dash. Si no hay cargas, set_blocking ignora.
	var can_block: bool = not is_attacking and not dash.is_dashing
	var wants_block: bool = Input.is_action_pressed("block") and can_block
	shield.set_blocking(wants_block)

	var dir: float = Input.get_axis("ui_left", "ui_right")
	if dir != 0.0:
		var new_facing: int = int(sign(dir))
		if new_facing != current_facing:
			_apply_facing(new_facing)
		# Velocidad reducida al 50% mientras bloqueás (decisión Leo).
		var speed_mult: float = 0.5 if shield.is_blocking else 1.0
		velocity.x = dir * SPEED * speed_mult
	else:
		velocity.x = move_toward(velocity.x, 0.0, SPEED)

	if Input.is_action_just_pressed("dash"):
		# Dash cancela el bloqueo (suelta y dasha).
		if shield.is_blocking:
			shield.set_blocking(false)
		dash.try_dash(current_facing)

	if Input.is_action_just_pressed("attack") and not is_attacking:
		# Attack cancela el bloqueo (suelta y golpea).
		if shield.is_blocking:
			shield.set_blocking(false)
		_start_attack()

	# Estado visual.
	if not is_attacking:
		if shield.is_blocking:
			sprite.set_state(StickFigure.State.BLOCK)
		elif not is_on_floor():
			sprite.set_state(StickFigure.State.JUMP)
		elif abs(velocity.x) > 10.0:
			sprite.set_state(StickFigure.State.WALK)
		else:
			sprite.set_state(StickFigure.State.IDLE)


func _start_attack() -> void:
	is_attacking = true
	_attack_time = 0.0
	_projectile_fired_this_attack = false
	sprite.set_state(StickFigure.State.ATTACK)
	# Garantizar facing al iniciar (defensivo — _apply_facing ya lo hace en cada cambio).
	_apply_facing(current_facing)
	# Aplicar multiplicador de Momentum al daño del swing actual.
	hitbox.damage_multiplier = MomentumSystem.damage_multiplier()

	# Detectar tipo de arma equipada para elegir entre melee y ranged.
	# Sword/Hammer/None → melee (hitbox toggle clásico).
	# Bow/Staff → ranged: spawn proyectil al inicio del swing, sin hitbox melee.
	var weapon: ItemData = InventorySystem.get_equipped(ItemData.Slot.ARMA)
	var visual: int = weapon.visual_type if weapon != null else StickFigure.WeaponType.NONE
	_is_ranged_attack = (visual == StickFigure.WeaponType.BOW \
		or visual == StickFigure.WeaponType.STAFF)


## Aplica un facing nuevo: actualiza sprite, hitbox y arma visible.
## Llamarlo cada vez que cambia la dirección — no solo al atacar.
func _apply_facing(dir: int) -> void:
	if dir == 0:
		return
	current_facing = dir
	sprite.set_facing(current_facing)
	# La hitbox sigue al facing siempre: si girás sin atacar, queda del lado correcto
	# para cuando ataques. Si la hitbox ya está activa (mid-swing), tampoco se rompe.
	hitbox.position.x = abs(hitbox.position.x) * current_facing


func _tick_attack(delta: float) -> void:
	if not is_attacking:
		return
	_attack_time += delta

	if _is_ranged_attack:
		# Disparar el proyectil al inicio de la ventana activa, una sola vez por attack.
		if _attack_time >= ATTACK_ACTIVE_START and not _projectile_fired_this_attack:
			_spawn_player_projectile()
			_projectile_fired_this_attack = true
	else:
		# Melee: hitbox activo solo en ventana ATTACK_ACTIVE_*.
		var should_be_active: bool = _attack_time >= ATTACK_ACTIVE_START and _attack_time <= ATTACK_ACTIVE_END
		if hitbox.monitoring != should_be_active:
			hitbox.set_active(should_be_active)

	if _attack_time >= ATTACK_DURATION:
		is_attacking = false
		_is_ranged_attack = false
		_projectile_fired_this_attack = false
		hitbox.set_active(false)


func _on_hit_landed(_target: HurtboxComponent) -> void:
	# Furia escala con Momentum (mismo multiplicador que daño).
	furia.add_on_hit(MomentumSystem.furia_multiplier())
	MomentumSystem.on_hit_landed()
	# Feedback "weight": mini freeze + shake leve al conectar.
	HitStop.freeze(0.05)
	CameraShake.shake(1.5, 0.08)


func _on_hit_received(amount: int, _source: HitboxComponent) -> void:
	# Recibir daño resetea Momentum (salvo bloqueo activo, manejado dentro del sistema).
	MomentumSystem.on_damage_taken()
	# Texto flotante ROJO encima del player.
	DamageFloater.spawn(get_tree().current_scene, global_position + Vector2(0, -70),
		amount, Color(1.0, 0.25, 0.25, 1.0))
	# Sin hit-stop al recibir daño: en multi-enemy se sentía como lag.
	# Solo screen-shake con cooldown (1/seg) para indicar el golpe sin marear.
	var now_ms: int = Time.get_ticks_msec()
	if now_ms - _last_damage_shake_ms >= DAMAGE_SHAKE_COOLDOWN_MS:
		_last_damage_shake_ms = now_ms
		var intensity: float = clamp(float(amount) / 30.0, 0.0, 1.0)
		CameraShake.shake(lerp(3.0, 10.0, intensity), 0.20)


func _on_momentum_threshold_reached() -> void:
	if momentum_particles != null:
		momentum_particles.emitting = true


func _on_momentum_threshold_lost() -> void:
	if momentum_particles != null:
		momentum_particles.emitting = false


# ─── Bloqueo: handlers ────────────────────────────────────────────────────────

func _on_block_started() -> void:
	sprite.start_block_aura()


func _on_block_ended() -> void:
	sprite.end_block_aura()


## Disparado por hurtbox cuando un golpe fue absorbido por el shield.
## Hace burst visual + floater "BLOCK!" + congela Momentum 1s (no resetea).
func _on_hit_blocked(_amount: int, _source: HitboxComponent) -> void:
	sprite.play_block_burst()
	MomentumSystem.on_block_absorbed()
	DamageFloater.spawn_text(get_tree().current_scene,
		global_position + Vector2(0, -70),
		"BLOCK!", Color(0.55, 0.85, 1.0, 1.0))
	# Feedback "absorb": mini freeze + shake leve (más sutil que recibir daño).
	HitStop.freeze(0.06)
	CameraShake.shake(2.0, 0.10)


## Recarga de cargas al completar etapa. GDD §4.3 (PvE).
func _on_stage_cleared(_index: int) -> void:
	shield.restore_all()


func _on_died() -> void:
	sprite.set_state(StickFigure.State.DEAD)
	set_physics_process(false)
	# Soltar bloqueo si estaba activo (evita aura/postura colgada tras morir).
	if shield != null and shield.is_blocking:
		shield.set_blocking(false)
	# Mostrar pantalla de Game Over con botón Reintentar.
	_spawn_game_over_screen()


## Instancia la UI de Game Over como hija del root para que sobreviva al
## set_physics_process(false) del player.
func _spawn_game_over_screen() -> void:
	var scene: PackedScene = preload("res://scenes/ui/game_over_screen.tscn")
	if scene == null:
		push_warning("Player: game_over_screen.tscn no encontrado.")
		return
	var screen: CanvasLayer = scene.instantiate() as CanvasLayer
	get_tree().current_scene.add_child(screen)


# ─── Refresh visual de armas según equipo ─────────────────────────────────────

func _on_equipped_changed(_slot: ItemData.Slot, _item: ItemData) -> void:
	_refresh_weapon_visuals()


## Lee InventorySystem.get_equipped() y actualiza weapon_main/off del StickFigure.
## Arma → main hand. Escudo → off hand. Si no hay arma, fists (NONE).
func _refresh_weapon_visuals() -> void:
	var weapon: ItemData = InventorySystem.get_equipped(ItemData.Slot.ARMA)
	# shield_item (no shield) para no shadowear @onready var shield: ShieldComponent.
	var shield_item: ItemData = InventorySystem.get_equipped(ItemData.Slot.ESCUDO)
	var main_type: int = StickFigure.WeaponType.NONE
	var off_type: int = StickFigure.WeaponType.NONE
	if weapon != null:
		main_type = weapon.visual_type
	if shield_item != null:
		# Si el escudo no tiene visual_type seteado, asumir SHIELD por slot.
		off_type = shield_item.visual_type if shield_item.visual_type != 0 else StickFigure.WeaponType.SHIELD
	sprite.set_weapons(main_type, off_type)


# ─── Ranged attacks (arco / vara) ─────────────────────────────────────────────

## Spawnea el proyectil según el visual_type del arma equipada.
## - Bow → arrow.
## - Staff → fireball.
## El daño usa el del hitbox (que ya tiene los stats del arma aplicados por
## PlayerStatsComponent) × multiplicador de Momentum.
func _spawn_player_projectile() -> void:
	var weapon: ItemData = InventorySystem.get_equipped(ItemData.Slot.ARMA)
	if weapon == null:
		return
	var scene: PackedScene
	match weapon.visual_type:
		StickFigure.WeaponType.BOW:   scene = PLAYER_ARROW_SCENE
		StickFigure.WeaponType.STAFF: scene = PLAYER_FIREBALL_SCENE
		_:
			return  # No es ranged, no debería estar acá.
	if scene == null:
		return
	var proj: Projectile = scene.instantiate() as Projectile
	if proj == null:
		push_warning("Player: projectile scene no instancia un Projectile.")
		return
	# Spawn point: a la altura del torso/mano frontal, offset hacia el facing.
	proj.global_position = global_position + Vector2(20.0 * current_facing, -45.0)
	# Daño final = hitbox.damage (arma + refinamiento) × multiplicador Momentum.
	var final_damage: int = int(round(float(hitbox.damage) * MomentumSystem.damage_multiplier()))
	proj.launch(Vector2(current_facing, 0.0), final_damage, team)
	# Suscribirse al hit del proyectil para ganar Furia + Momentum al impactar.
	proj.hit_landed.connect(_on_projectile_hit_landed)
	get_tree().current_scene.add_child(proj)


func _on_projectile_hit_landed(target: HurtboxComponent) -> void:
	# Mismo efecto que un hit melee: gana Furia + sube Momentum.
	_on_hit_landed(target)

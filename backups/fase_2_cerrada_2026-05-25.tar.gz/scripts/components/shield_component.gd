extends Node
class_name ShieldComponent

## Cargas de bloqueo del escudo equipado. ESTADO RUNTIME.
##
## Las cargas NO viven en el .tres (recurso compartido) sino acá.
## Se reconfigura cuando InventorySystem.equipped_changed dispara para slot ESCUDO.
##
## GDD §4.3 / §5.2:
## - R1: 0 cargas (no bloquea). R2: 1. R3: 2. R4: 3.
## - Recarga: al completar etapa (PvE). Coliseo sin recarga (post-MVP).
## - Bloquear absorbe el golpe completo y congela Momentum 1s.

signal charges_changed(current: int, maximum: int)
signal block_started
signal block_ended
signal charge_absorbed(remaining: int)

var max_charges: int = 0
var current_charges: int = 0
var is_blocking: bool = false


func _ready() -> void:
	# Sincronizar con el escudo ya equipado al arrancar (deferred porque
	# InventorySystem y player_stats setean equipo en call_deferred al inicio).
	call_deferred("_initial_sync")
	if InventorySystem != null:
		InventorySystem.equipped_changed.connect(_on_equipped_changed)


func _initial_sync() -> void:
	if InventorySystem == null:
		return
	var shield: ItemData = InventorySystem.get_equipped(ItemData.Slot.ESCUDO)
	_configure_from_item(shield)


## Pedido del player: activar/desactivar bloqueo.
## Si pedís activar sin cargas, no pasa nada (return silencioso).
func set_blocking(value: bool) -> void:
	if value == is_blocking:
		return
	if value and current_charges <= 0:
		return
	is_blocking = value
	if is_blocking:
		block_started.emit()
	else:
		block_ended.emit()


func has_charges() -> bool:
	return current_charges > 0


## Llamado por HurtboxComponent al recibir hit. Si bloqueando y hay carga:
## consume una y retorna true (el daño NO se aplica). Sino, retorna false.
func try_absorb() -> bool:
	if not is_blocking or current_charges <= 0:
		return false
	current_charges -= 1
	charges_changed.emit(current_charges, max_charges)
	charge_absorbed.emit(current_charges)
	# Si fue la última carga, salimos del bloqueo (no podés seguir bloqueando vacío).
	if current_charges <= 0:
		is_blocking = false
		block_ended.emit()
	return true


## Restaurar cargas al máximo. Llamar al completar etapa (PvE).
func restore_all() -> void:
	if max_charges <= 0:
		return
	current_charges = max_charges
	charges_changed.emit(current_charges, max_charges)


func _on_equipped_changed(slot: int, item: ItemData) -> void:
	if slot != ItemData.Slot.ESCUDO:
		return
	_configure_from_item(item)


## Configura max/current según el escudo equipado. Cambiar escudo
## resetea las cargas (asumimos full al equipar, consistente con PvE start).
func _configure_from_item(item: ItemData) -> void:
	var new_max: int = 0
	if item != null and item.is_shield():
		new_max = item.block_charges()
	max_charges = new_max
	current_charges = new_max
	# Salir del bloqueo si quedamos sin cargas tras el cambio.
	if is_blocking and current_charges <= 0:
		is_blocking = false
		block_ended.emit()
	charges_changed.emit(current_charges, max_charges)

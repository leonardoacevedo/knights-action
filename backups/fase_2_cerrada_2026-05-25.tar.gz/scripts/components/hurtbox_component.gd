extends Area2D
class_name HurtboxComponent

## Area2D que recibe daño de Hitboxes enemigos.
## Requiere HealthComponent en el mismo entity (configurar via @export o setter).

signal hit_received(amount: int, source: HitboxComponent)
## Emitido cuando el golpe fue absorbido por un ShieldComponent activo con cargas.
## El daño NO se aplicó al HealthComponent. El owner (player) reacciona con
## efectos visuales y congelar Momentum.
signal hit_blocked(amount: int, source: HitboxComponent)

## Team del owner. 1=player, 2=enemy.
@export var team: int = 0
## Referencia al HealthComponent del entity. Asignar en Inspector o setear via código.
@export var health_component: HealthComponent
## Opcional: si está seteado y tiene método try_absorb() -> bool, el golpe se absorbe.
## El player pasa un ShieldComponent; los enemies pasan un EnemyBlockHandler.
## Tipo Node (duck typing) para soportar ambas implementaciones sin herencia.
@export var shield: Node

## Si true, ignora hits (útil durante i-frames de dash).
var invulnerable: bool = false

## Reducción flat de daño por defensa de equipamiento.
## Seteado por PlayerStatsComponent. Daño mínimo garantizado: 1.
var flat_defense: int = 0

func _ready() -> void:
	# Layer 5 = Hurtbox. Mask 4 = detecta Hitbox.
	collision_layer = 0b10000    # bit 5
	collision_mask = 0b1000      # bit 4
	monitoring = false           # nosotros no buscamos, ellos nos encuentran
	monitorable = true


## source puede ser null cuando el daño viene de un Projectile (no Hitbox).
func receive_hit(amount: int, source: HitboxComponent = null) -> void:
	if invulnerable:
		return
	if health_component == null:
		push_warning("HurtboxComponent sin health_component asignado: %s" % get_path())
		return
	# Bloqueo: si el shield absorbe, NO descontamos HP y avisamos al owner.
	if shield != null and shield.try_absorb():
		hit_blocked.emit(amount, source)
		return
	# Defensa flat reduce daño. Mínimo garantizado: 1. Fórmula: formulas.md §Equipamiento.
	var mitigated: int = max(1, amount - flat_defense)
	health_component.take_damage(mitigated)
	hit_received.emit(mitigated, source)


func set_invulnerable(value: bool) -> void:
	invulnerable = value

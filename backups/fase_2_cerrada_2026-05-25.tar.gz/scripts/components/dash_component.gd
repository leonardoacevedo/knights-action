extends Node
class_name DashComponent

## Dash con i-frames + cooldown. GDD §4.3.
## 6 frames de invulnerabilidad (~100ms a 60fps). Cooldown 0.8s.
## Ventana de habilidad, no escape gratuito.

signal dash_started
signal dash_ended
signal cooldown_finished

@export var dash_speed: float = 1200.0
@export var dash_duration: float = 0.1     # ~6 frames a 60fps
@export var cooldown: float = 0.8
## Si está seteado, el dash setea invulnerable en este hurtbox durante i-frames.
@export var hurtbox: HurtboxComponent

var is_dashing: bool = false
var can_dash: bool = true
var dash_direction: int = 1

var _duration_timer: float = 0.0
var _cooldown_timer: float = 0.0


func _process(delta: float) -> void:
	if is_dashing:
		_duration_timer -= delta
		if _duration_timer <= 0.0:
			_end_dash()

	if not can_dash and not is_dashing:
		_cooldown_timer -= delta
		if _cooldown_timer <= 0.0:
			can_dash = true
			cooldown_finished.emit()


func try_dash(direction: int) -> bool:
	if not can_dash or is_dashing:
		return false
	is_dashing = true
	can_dash = false
	dash_direction = sign(direction) if direction != 0 else 1
	_duration_timer = dash_duration
	_cooldown_timer = cooldown
	if hurtbox != null:
		hurtbox.set_invulnerable(true)
	dash_started.emit()
	return true


func _end_dash() -> void:
	is_dashing = false
	if hurtbox != null:
		hurtbox.set_invulnerable(false)
	dash_ended.emit()


func get_dash_velocity_x() -> float:
	return dash_direction * dash_speed if is_dashing else 0.0

extends Area2D
class_name HitboxComponent

## Area2D que aplica daño al entrar a un HurtboxComponent.
## Activable/desactivable. Sistema de teams previene friendly fire.

signal hit_landed(target_hurtbox: HurtboxComponent)

@export var damage: int = 5
## Team del owner. 1=player, 2=enemy. Solo daña a Hurtbox de team distinto.
@export var team: int = 0
## Si true, hitbox arranca activo. Default false (combate usa toggle).
@export var active_on_start: bool = false

## Multiplicador runtime aplicado al damage final. Lo setea el entity (player desde Momentum).
## Default 1.0 = sin cambio.
var damage_multiplier: float = 1.0

func _ready() -> void:
	# Layer 4 = Hitbox. Mask 5 = detecta Hurtbox.
	collision_layer = 0b1000     # bit 4
	collision_mask = 0b10000     # bit 5
	monitoring = true
	monitorable = false           # otros hitbox no nos detectan
	set_active(active_on_start)
	area_entered.connect(_on_area_entered)


func set_active(value: bool) -> void:
	# Toggle por monitoring evita procesar colisiones cuando no corresponde.
	monitoring = value
	# Disable shapes también, defensa en profundidad.
	for child in get_children():
		if child is CollisionShape2D or child is CollisionPolygon2D:
			child.set_deferred("disabled", not value)


func _on_area_entered(area: Area2D) -> void:
	if not area is HurtboxComponent:
		return
	var hurtbox: HurtboxComponent = area
	if hurtbox.team == team:
		return  # mismo team, no daño
	var final_damage: int = int(round(float(damage) * damage_multiplier))
	hurtbox.receive_hit(final_damage, self)
	hit_landed.emit(hurtbox)

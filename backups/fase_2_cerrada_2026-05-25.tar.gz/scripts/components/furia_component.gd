extends Node
class_name FuriaComponent

## Furia: recurso para skills. GDD §4.3.
## No regenera pasivamente. Solo sube por golpes (+10/hit).
## Decay: tras 5s sin atacar, pierde 5 Furia/s. Refuerza agresividad.

signal furia_changed(current: int, maximum: int)
signal furia_full
signal furia_empty

@export var max_furia: int = 100
@export var gain_per_hit: int = 10
@export var decay_per_second: float = 5.0
@export var decay_starts_after_seconds: float = 5.0

var current_furia: float = 0.0   # float para decay suave
var _seconds_since_last_attack: float = 0.0


func _process(delta: float) -> void:
	_seconds_since_last_attack += delta
	if _seconds_since_last_attack >= decay_starts_after_seconds:
		_apply_decay(delta)


func add_on_hit(multiplier: float = 1.0) -> void:
	# Llamar desde HitboxComponent.hit_landed (entity orquesta).
	# multiplier: escala la ganancia. Player lo usa para aplicar Momentum.furia_multiplier().
	_seconds_since_last_attack = 0.0
	var old: int = int(current_furia)
	var gain: float = float(gain_per_hit) * multiplier
	current_furia = min(float(max_furia), current_furia + gain)
	if int(current_furia) != old:
		furia_changed.emit(int(current_furia), max_furia)
	if int(current_furia) >= max_furia:
		furia_full.emit()


func try_spend(amount: int) -> bool:
	if int(current_furia) < amount:
		return false
	current_furia -= float(amount)
	furia_changed.emit(int(current_furia), max_furia)
	if int(current_furia) <= 0:
		furia_empty.emit()
	return true


func get_current() -> int:
	return int(current_furia)


func get_percent() -> float:
	if max_furia <= 0:
		return 0.0
	return current_furia / float(max_furia)


func _apply_decay(delta: float) -> void:
	if current_furia <= 0.0:
		return
	var old: int = int(current_furia)
	current_furia = max(0.0, current_furia - decay_per_second * delta)
	if int(current_furia) != old:
		furia_changed.emit(int(current_furia), max_furia)
	if current_furia <= 0.0:
		furia_empty.emit()

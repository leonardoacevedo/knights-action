extends Node
class_name PlayerStatsComponent

## Aplica stats de equipamiento al player.
## Lee InventorySystem.get_equipped() en cada equipped_changed y empuja
## los resultados a HealthComponent + HitboxComponent + HurtboxComponent.
##
## Fórmula base (formulas.md §Equipamiento):
##   stats_totales = stats_base(nivel) + stats_equipamiento + bonus_skills + bonus_set
## Por ahora: stats_base + equipamiento (skills y set bonus son futuro).
##
## HP al re-equipar: absoluto. Si tenías 80/100 y max sube a 110 → 80/110.
## Si max baja por debajo del HP actual, se clampea al nuevo max.

# ─── Stats base del player ────────────────────────────────────────────────────
# Source of truth: GameConfig autoload (scripts/systems/game_config.gd).
# Es el "archivo .env" del proyecto. Editar allí para tunear balance.
# NO duplicar constantes acá — se leen runtime de GameConfig.PLAYER_BASE_*.

# ─── Referencias a componentes del mismo entity ───────────────────────────────

## Asignar en el _ready del Player (inyección, no get_parent).
var health: HealthComponent
var hitbox: HitboxComponent
var hurtbox: HurtboxComponent

## Override de inventario para tests unitarios (headless no carga autoloads).
## En producción: null → usa InventorySystem autoload.
var _inv: Node = null


func _ready() -> void:
	# Conecta al inventario activo. En tests, _inv puede setearse ANTES de add_child.
	_get_inv().equipped_changed.connect(_on_equipped_changed)


## Retorna el inventario activo: override si fue seteado, InventorySystem si no.
func _get_inv() -> Node:
	return _inv if _inv != null else InventorySystem


# ─── API pública ──────────────────────────────────────────────────────────────

## Recalcula todos los stats a partir del equipo actual.
## Llamar manualmente en _ready del player (estado inicial).
func recalculate() -> void:
	if health == null or hitbox == null or hurtbox == null:
		push_error("PlayerStatsComponent: referencias no seteadas antes de recalculate()")
		return

	var inv := _get_inv()
	var weapon: ItemData = inv.get_equipped(ItemData.Slot.ARMA)
	var armor: ItemData  = inv.get_equipped(ItemData.Slot.ARMADURA)
	var shield: ItemData = inv.get_equipped(ItemData.Slot.ESCUDO)

	# Log de afijos desconocidos antes de aplicar (una vez por recalculate).
	for item in [weapon, armor, shield]:
		if item != null:
			_warn_unknown_affixes(item)

	_apply_damage(weapon)
	_apply_health_and_defense(armor, shield)


# ─── Privado ──────────────────────────────────────────────────────────────────

func _on_equipped_changed(_slot: ItemData.Slot, _item: ItemData) -> void:
	recalculate()


func _apply_damage(weapon: ItemData) -> void:
	# Daño base del arma con refinamiento, o GameConfig.PLAYER_BASE_DAMAGE si no hay arma.
	if weapon == null:
		hitbox.damage = GameConfig.PLAYER_BASE_DAMAGE
		return

	# refined_stat() ya aplica la fórmula GDD §5.6.
	# Fórmula documentada en .claude/docs/formulas.md.
	hitbox.damage = int(round(weapon.refined_stat()))


func _apply_health_and_defense(armor: ItemData, shield: ItemData) -> void:
	# Defensa y HP: suma stats_main de armadura + escudo + afijos relevantes.
	var total_defense: int = GameConfig.PLAYER_BASE_DEFENSE
	var bonus_hp: int = 0

	# Armadura
	if armor != null:
		total_defense += int(round(armor.refined_stat()))
		bonus_hp += _sum_affix(armor, &"hp")
		total_defense += _sum_affix(armor, &"defense")

	# Escudo
	if shield != null:
		total_defense += int(round(shield.refined_stat()))
		bonus_hp += _sum_affix(shield, &"hp")
		total_defense += _sum_affix(shield, &"defense")

	# Arma también puede tener afijos de HP o defense (raro pero válido por schema).
	var weapon: ItemData = _get_inv().get_equipped(ItemData.Slot.ARMA)
	if weapon != null:
		bonus_hp += _sum_affix(weapon, &"hp")

	# Aplicar HP máximo.
	var new_max: int = GameConfig.PLAYER_BASE_HEALTH + bonus_hp
	_set_max_health(new_max)

	# Aplicar defensa flat al hurtbox.
	hurtbox.flat_defense = total_defense


func _sum_affix(item: ItemData, stat_id: StringName) -> int:
	# Suma los afijos con el stat_id exacto. Sin warnings acá — ver _warn_unknown_affixes.
	var total: int = 0
	for affix: AffixData in item.affixes:
		if affix != null and affix.stat_id == stat_id:
			total += affix.value
	return total


## IDs de afijos que PlayerStatsComponent conoce.
const KNOWN_AFFIX_IDS: Array[StringName] = [&"hp", &"defense", &"attack_speed"]

func _warn_unknown_affixes(item: ItemData) -> void:
	# Log único por item por recalculate — no por cada llamada a _sum_affix.
	for affix: AffixData in item.affixes:
		if affix == null:
			continue
		if affix.stat_id not in KNOWN_AFFIX_IDS:
			push_warning("PlayerStatsComponent: afijo desconocido '%s' en item '%s' — ignorado" \
				% [affix.stat_id, item.id])


func _set_max_health(new_max: int) -> void:
	# Conserva HP absoluto. Clampea si max baja por debajo del HP actual.
	# Ver docs/features/equipment/items_apply_to_player.md §Decisiones.
	var previous_current: int = health.current_health
	health.max_health = new_max
	health.current_health = min(previous_current, new_max)
	# Notificar HUD / listeners.
	health.health_changed.emit(health.current_health, health.max_health)

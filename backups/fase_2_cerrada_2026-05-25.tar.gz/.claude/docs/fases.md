# Plan de Fases — Knights Action

Basado en §13 del GDD. **Total estimado: 14-18 meses** (multiplicar ×1.5-2 para realidad de dev solo).

## Fase 1 — Prototipo de Combate (2-3 meses) ✅ **CERRADA** (24/05/2026)

### Hito
*"Pelear se siente bien."* — Validado por Leo end-to-end.

### Scope entregado
- Player: movimiento + salto + dash con i-frames + ataque melee/ranged + bloqueo con cargas.
- **Sistema de Momentum** (autoload `MomentumSystem`).
- **Furia con decay** (-5/s tras 5s sin atacar).
- **Bloqueo con cargas** (`ShieldComponent`, signal `hit_blocked`, freeze Momentum al absorber).
- **Telegrafía enemy** ("!" amarillo bouncing en el último 40% del wind-up).
- **Hit-stop** global + **screen-shake** con decay (`HitStop`, `CameraShake` autoloads).
- **Game Over + Reintentar** modal.
- Touch HUD completo (joystick + 6 botones, flag `GameConfig.PLATFORM_MODE`).
- Bugfixes: facing del swing, enemy muerto desvanece, auto-jump joystick, TouchButton stuck.

### Lecciones / bugs Godot 4 documentados
- `.tscn` NO soporta comentarios `#` (parser silenciosamente saltea el siguiente `[node]`).
- `TouchButton` debe emitir `InputEventAction` sintético + tener poll defensivo de auto-release para sobrevivir CanvasLayer modales.
- Hit-stop al recibir daño se siente como lag en multi-enemy — solo se aplica al PEGAR/BLOQUEAR.

### Retrospectiva
Pendiente en `docs/features/phase_1_retrospective.md`.

---

## Fase 2 — Loop Básico (2-3 meses) ← **ESTAMOS ACÁ**

### Hito
*"El loop pelear → lootear → mejorar engancha."*

### Scope
- 3 tipos de enemigos placeholder (R1/R2/R3 visualmente diferenciados).
- Drop de items al matar.
- Inventario básico (equipar/desequipar). **[ya existe `InventorySystem` de Fase 1 — auditar]**
- **Crafteo** simple con materiales drop.
- **Sistema de Refinamiento** (+1 a +10) con UI completa (probabilidades visibles, animación de intento, Pergaminos de Protección).
- Ajustes de feel del combate de Fase 1 que surjan del playtest.

### Estado actual (25/05/2026)
- ✅ **Drops Milestone A** — materiales por kill, fórmula GDD §111, toast UI, 4 materiales, drop tables por rareza R1/R2/R3 auditadas, 6 tests integración + 12 tests unitarios. Bugs CRITICAL fixeados.
- ✅ **Drops Milestone B** — items por stage_cleared, signal `items_dropped`, loot card UI con bloqueo del flow vía `paused`, drop tables E2/E3/E4. Doc consolidado en `drops_milestone_a.md`.
- ✅ **3 enemigos R1/R2/R3 diferenciados** — R2 bloquea, R3 dashea + skill, tints visuales. Nerf R3 + dist-check aplicados.
- ✅ **Refinamiento +1 a +10** — backend (UpgradeManager, RefineResult, Pergamino, 12 tests) + UI completa (RefinementScreen procedural, probabilidades visibles, animación de intento). Botón "Refinar" integrado en InventoryScreen.
- ✅ **Crafteo backend + UI** — CraftingSystem autoload, 5 recetas iniciales (cota_cuero, espada_hierro, escudo_hierro, vara_cristal, martillo_guardian), CraftingScreen modal, botón "Forja" en InventoryScreen header.
- ✅ **UI Inventario de materiales** — sección dedicada en InventoryScreen, cache de MaterialData, reactive a signals, ordenado por rareza.
- ✅ **NICE-TO-HAVE InventorySystem** — count<=0 guard, signal `material_removed`, reset() con `quiet`.
- ✅ **Bestiario inicial Zona 1** — lore para 7 especies + 4 materiales + Valle de los Ecos en `docs/lore/`.
- ✅ **Fix StageManager._is_pending en reset()** + glosario actualizado con Piedra de Resonancia + retro Fase 1.
- ⏳ **Aplicar stats del equipo al player** — InventorySystem permite equipar pero los stats no impactan combate. Brecha crítica del loop "mejorar".
- ⏳ **Validación end-to-end en Godot** — Leo pendiente de playtest tras los bugfixes (ambient_tint restaurado, boss R4 en _wip).
- ✅ **Boss R4 "El Guardián de la Maleza"** — restaurado de `_wip/` + ajustado según feedback playtest (4 cargas reales no miss-shield, regen, gap-close dash, 5 patrones, scale 2.0, partículas verde-doradas). Integrado a `world.gd`. Doc en `docs/features/bosses/guardian_maleza.md`.
- ✅ **Post-playtest fixes 25/05/2026 noche:** Fix 1 bloqueo enemy con cargas reales (`EnemyBlockHandler`), Fix 2 telegraph melee/tank más rápidos (0.25/0.4s), Fix 3 items dropeados ahora son copias independientes (no comparten `refinement_level`), Fix 4 boss R4 integrado.

### Criterio para cerrar fase
Leo (o un tester) juega 30 min y siente que el loop "engancha" — quiere otra etapa, quiere refinar el arma, quiere ver el próximo drop.

---

## Fase 3 — Sistemas RPG Completos (3-4 meses)

### Hito
*"Una zona completa es jugable de principio a fin."*

### Scope
- **Árbol de skills** (~30 nodos, 3 ramas).
- **Elementos** Tierra/Fuego/Agua con triángulo.
- **Set bonuses** (afinidad de equipo 2pc/3pc).
- **Momentum integrado en UI** finalizada.
- **Primera zona completa** (Valle de los Ecos): 6 etapas + boss El Guardián de la Maleza.
- **Arte de la zona generado por IA** (Midjourney/SD).
- Parallax de la zona, sprites de los 3 enemigos y boss.
- Música de zona (1 track) y de combate.

### Criterio para cerrar fase
Un tester nuevo termina la zona, vence al boss y entiende el sistema RPG sin tutorial extenso.

---

## Fase 4 — Coliseo (2-3 meses)

### Hito
*"Puedo subir mi Eco y pelear contra el de otro tester."*

### Scope
- Backend (Firebase o Supabase) configurado.
- **Upload de Eco** con build + telemetría.
- **Asignación de Perfil IA** (1 de 4).
- **Matchmaking asíncrono** (3 Ecos candidatos por Gloria similar).
- **Sistema de Gloria** con +/- por victoria/derrota.
- **Ranking** y leaderboard global.
- UI del Coliseo completa.
- Anti-cheat básico (validación al subir).

### Criterio para cerrar fase
2-3 testers suben sus Ecos, pelean entre sí asíncronamente, el ranking refleja sus skills relativos.

---

## Fase 5 — Pulido y Lanzamiento (3-4 meses)

### Hito
*"Listo para soft launch."*

### Scope
- Arte final de toda la zona (no placeholders).
- Audio final (música + SFX completo).
- UX móvil afinada — testing en dispositivos reales (Android y iOS).
- Balance final (curvas validadas con datos de los testers).
- Misiones diarias funcionales.
- Bestiario completo con lore.
- Optimización (carga, memoria, fps en mid-range).
- Tienda básica (si aplica — definir con Leo si MVP tiene store de cosméticos).
- Política de privacidad, T&C, GDPR mínimo.

### Criterio para cerrar fase
APK / IPA en TestFlight / Internal Testing con ~50 jugadores reales por 1 semana sin crashes mayores.

---

## Reglas inviolables del plan

1. **No saltarse fases.** Si Fase 1 no se siente bien, Fase 2 no arregla nada.
2. **Cada hito requiere un playtest validatorio** antes de cerrar.
3. **El alcance de cada fase es el §13 del GDD + acuerdo con Leo.** Si algo se mueve entre fases, documentarlo en este archivo.
4. **No agregues contenido a una fase para "cubrir un agujero" de la siguiente.** Mejor cerrar la fase y arrancar la próxima limpia.
5. **Documentá lo aprendido al cerrar cada fase** en `docs/features/phase_<N>_retrospective.md`.

## Post-launch — Backlog (NO entra al MVP)

- Zonas 2 (Fuego) y 3 (Agua) con sus bosses.
- Rareza R4 Legendaria.
- Elementos Viento, Rayo, Sombra.
- Sistema de Reliquias (roguelite-lite).
- Logros y cosméticos.
- Eventos de temporada en Coliseo.
- Localización (inicialmente solo castellano).

Source: GDD §11.

---

## Riesgos identificados (§14 GDD) — recordatorio

| Riesgo | Mitigación |
| :--- | :--- |
| Performance animación skeletal mobile | Limitar huesos <20, usar AnimationTree |
| UI de 5+joystick en pantalla chica | Probar en celular real desde **Fase 1**, no en PC |
| Corrupción de saves | Backup local + cloud desde día 1 |
| Backend Coliseo costoso | Firebase free tier para soft launch, migrar si escala |
| Inconsistencia visual IA generativa | Template maestro reusado siempre |
| Scope creep | Releer pilares antes de cada decisión |
| Burnout de dev solo | Sprints cortos, pausas planificadas |

Mantener estos en vista durante todas las fases.

# Zona: Valle de los Ecos — Arquitectura de Pacing

**Fecha:** 25/05/2026
**Autor:** level-designer (Claude subagente)
**Referencia GDD:** §7 (Estructura de Zona), §7.2 (Eco Profundo), §7.3 (Escalado de IA por rareza), §10 (Zona MVP)

---

## Arquitectura real de la zona

La zona MVP tiene **4 etapas** (no las 5-8 del GDD §7.1 — ver Pendientes):

| # | Archivo | Función |
|---|---------|---------|
| E1 | `zona1_etapa_1.tres` | Introducción suave |
| E2 | `zona1_etapa_2.tres` | Primera exposición a rarezas mixtas |
| E3 | `zona1_etapa_3.tres` | Presión sostenida, R2 dominante |
| E4 | `zona1_etapa_4.tres` | Boss fight — Guardián de la Maleza |

---

## Tabla de composición final (todas las etapas)

| Etapa | Enemies | Total | Rarezas presentes |
|-------|---------|-------|-------------------|
| E1 — Avanzada de Vanguardia | Melee R1 ×3, Archer R1 ×2 | 5 | R1 puro |
| E2 — Pelotón de Guarnición | Melee R1 ×2, Tank R2 ×1, Melee R3 ×1 | 4 | R1 + R2 + R3 |
| E3 — Cacería de Élites | Melee R1 ×1, Tank R2 ×2, Archer R2 ×1, Mage R3 ×1 | 5 | R1 + R2 + R3 |
| E4 — Guardián de la Maleza | Tank R4 ×1 | 1 | R4 (boss) |

> E2 no fue modificada en esta sesión. Se documenta para referencia completa del diseño de la zona.

---

## Justificación pedagógica

### E1: Introducción suave (R1 puro, mix melee/ranged)

E1 enseña los fundamentos del combate sin presión. Los 3 Melee R1 son directos, sin bloqueo ni habilidades especiales (R1 = telegrafía simple, sin bloqueo, §7.3). Los 2 Archer R1 introducen que los enemies pueden atacar desde distancia sin acercarse — el jugador aprende a manejar el espacio y a elegir a quién golpear primero. Todos R1 garantiza que la muerte en E1 solo ocurre por ignorar telégrafos obvios: la fantasía del jugador no se rompe, enseña sin frustrar.

### E2: Primera exposición a rarezas mixtas

E2 introduce la mezcla que define el juego: un R1 de punching bag para mantener Momentum, un Tank R2 que bloquea ocasionalmente (el jugador aprende a esperar ventanas), y un Melee R3 que dashea y tiene skill (§7.3 R3). Cuatro enemies en total — dosis controlada. El objetivo es que el jugador salga de E2 sabiendo que existen distintos niveles de amenaza, no solo "más HP".

### E3: Presión sostenida, R2 dominante

E3 consolida lo aprendido. El R1 Melee sigue ahí como punching bag inicial — el jugador necesita un golpe fácil para arrancar el Momentum antes de comprometerse con los dos Tank R2. El Archer R2 presiona desde atrás mientras el jugador tankea a los Melee, forzando posicionamiento activo. El Mage R3 introduce amenaza ranged de alta rareza: si el jugador lo ignora pierde; si lo prioriza, abre la espalda a los R2. Cinco enemies totales — el límite para que la pantalla no se sienta caótica en mobile.

### E4: Clímax — Boss R4

Un solo enemigo que funciona como espejo del jugador (§7.3 R4). La drop table propia (`zona1_etapa_4_materials.tres`) incluye `esencia_verdor` con chance 10% — material premium que no aparece en E1-E3 — incentivando al jugador a llegar al boss en cada run.

---

## Drop tables y Momentum

Cada entry de spawn tiene `material_drops` asignado a la drop table de su rareza:

- R1 entries → `enemy_r1_materials.tres` (hierba × 65%, piedra × 15%)
- R2 entries → `enemy_r2_materials.tres`
- R3 entries → `enemy_r3_materials.tres` (recientemente nerfeada)
- Boss (E4) → `zona1_etapa_4_materials.tres` (drop table propia con esencia_verdor)

El `material_drops` de stage level actúa como fallback si una entry no tiene drop table propia (§5.5 DropSystem). Con el setup actual, todas las entries tienen drop table explícita — el fallback de stage no debería activarse en condiciones normales.

El sistema de Momentum (§10 Fórmulas) escala `drop_rate = base * (1 + 0.1 * momentum)`. En E1 con Momentum en 1x el jugador ve pocos drops; si aprende a no recibir golpes y llega a E3 con Momentum alto, los drops se sienten como recompensa proporcional a la skill.

---

## Pendientes

### Boss R4 placeholder
La entry actual en E4 (`Tank R4 ×1`) es un placeholder de clase Tank con rareza R4. El boss real — Guardián de la Maleza (§10 GDD) — debe ser diseñado por `boss-designer` con patrones propios, fases, telegrafía obligatoria y posiblemente su propia `boss_scene`. La entry de spawn debería actualizarse para referenciar la escena de boss cuando esté disponible.

### Drop table de boss con materiales premium
`zona1_etapa_4_materials.tres` existe y funciona, pero reutiliza materiales que también dropean en etapas anteriores (hierba, piedra, savia). Una drop table de boss real debería incluir al menos un material exclusivo de boss (ej. `colmillo_guardian.tres`) para diferenciar el premio de completar la zona del loot de etapas normales. Decisión de Leo + balance-engineer.

### Extensión de etapas
GDD §7.1 especifica 5-8 etapas + boss final. El Valle de los Ecos actualmente tiene solo 3 etapas de combate + boss (4 total). Si Leo decide extender la zona, las etapas faltantes deberían introducir:
- E3b o E4 (pre-boss): encuentro de élite único, posible R3 con modifier ambiental (trampa de raíces, plataforma inestable). Checkpoint aquí.
- Eco Profundo: una vez completa la zona, reactivar las mismas escenas con enemies +20 niveles, IA R2/R3 mínimo, sin checkpoints intermedios (§7.2).

---

## Campos NO modificados en esta sesión

Los siguientes campos fueron preservados intactos:

- E1: `uid`, `display_name`, `subtitle`, `stage_index` (agregado), `material_drops` de stage (fallback), `is_boss`
- E3: `uid`, `stage_index`, `display_name`, `subtitle`, `ambient_tint`, `platform_overrides` (5 plataformas), `hide_default_platforms`, `show_decorations`, `material_drops` de stage (fallback), `is_boss`
- E4: todo — ningún campo tocado
